def one():
    return 2
